export class Product{
    id: number;
    pid:number;
    name: string;
    description: string;
    price: number;
}